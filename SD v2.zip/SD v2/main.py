import tkinter as tk
from tkinter import ttk
from tkinter import *
from tkinter import messagebox
from threading import Thread
import time
import pyautogui
import os

# SH- shutdown, CU- custom, CR- crash, TR- tryout

global program_mode
global CMDCOMMAND

global root
global SDWindow
global crashWindow
global tryOutWindow
global customWindow
global program_mode
global statusVar


#mode_init code begins###################################################################################################

def mode_init(mode):
    f = open("assets/programMode.txt", "w")
    f.write(mode)
    f.close()
    print(mode)
    global program_mode
    program_mode = mode
    # this is the function called when the button is clicked
    def stopBtn_ModeInit():
            exit()



    modeInitWin = Tk()

    # This is the section of code which creates the main window
    modeInitWin.geometry('330x110+0+0')
    modeInitWin.attributes('-topmost', True)
    modeInitWin.overrideredirect(True)
    modeInitWin.title('SDv2_modeInit')

    global statusVar

    # This is the section of code which creates the a label
    statusVar = StringVar()
    
    Label(modeInitWin, textvariable=statusVar).place(x=12, y=4)
    statusVar.set("-----------")


    # This is the section of code which creates a button
    Button(modeInitWin, text='[X] Stop', command=stopBtn_ModeInit).place(x=242, y=64)

    global countdown
    global countdownNum

    countdownNum = StringVar()

    countdown = Label(modeInitWin, textvariable=countdownNum).place(x=242, y=24)

    countdownNum.set("10 sec.")

    def detectFunc():
        f = open("assets/programMode.txt", "r")
        global program_mode
        program_mode = f.read()
        if program_mode == "TR" or program_mode == "SH" or program_mode == "CU" or program_mode == "CR":
            pass
        else:
            messagebox.showerror("Error", "programMode.txt has been corrupted\nor tampered with. Please restart this program.")
            exit()
        global statusVar
        laststatus="t"
        damagecount=0
        while True:

            title = pyautogui.locateCenterOnScreen('assets/cc.png', confidence = 0.7)
            if str(title).lower() == "none":


                start = pyautogui.locateCenterOnScreen('assets/fullhealth.png')
                if str(start).lower() == "none":

                    if laststatus=="t":
                        damage=False
                    else:
                        
                        damagecount += 1

                        if damagecount >= 2:
                            
                            damage=True

                            global statusVar

                            if program_mode == "TR":
                                
                                statusVar.set("!!! Damage Taken !!!")
                                
                            elif program_mode == "SH":
                                
                                os.system('shutdown -s -t 1 -c "you took damage. you know the consequences."')
                                exit()
                                
                            elif program_mode == "CR":
                                
                                os.system("taskkill /im javaw.exe /f /t")
                                exit()
                                
                            elif program_mode == "CU":
                            
                                os.system(commandthing)
                                
                        else:
                            
                            damage=False
                            
                else:
                    
                    laststatus="n"
                    statusVar.set("No Damage")

            else:

                laststatus="t"
                statusVar.set("Pause Screen/Inventory")

            time.sleep(0.1)

    def countDownFunc():
        global countdownNum
        global pr
        time.sleep(1)
        countdownNum.set("9 sec.")
        time.sleep(1)
        countdownNum.set("8 sec.")
        time.sleep(1)
        countdownNum.set("7 sec.")
        time.sleep(1)
        countdownNum.set("6 sec.")
        time.sleep(1)
        countdownNum.set("5 sec.")
        time.sleep(1)
        countdownNum.set("4 sec.")
        time.sleep(1)
        countdownNum.set("3 sec.")
        time.sleep(1)
        countdownNum.set("2 sec.")
        time.sleep(1)
        countdownNum.set("1 sec.")
        time.sleep(1)
        countdownNum.set("Starting")
        time.sleep(1)
        detect = Thread(target=detectFunc)
        detect.start()
        countdownNum.set("Started")
        time.sleep(0.5)
        countdownNum.set("")
        
    t = Thread(target=countDownFunc, args=())

    t.start()
    #cd.start() threading

    global root
    global SDWindow
    global crashWindow
    global tryOutWindow
    global customWindow

    # This is the section of code which creates the a label
    if mode == "TR":
        
        Label(modeInitWin, text=f'Mode: Try Out').place(x=12, y=34)
        
    elif mode == "CU":
        
        Label(modeInitWin, text=f'Mode: Custom').place(x=12, y=34)
        
    elif mode == "CR":
        
        Label(modeInitWin, text=f'Mode: Crash').place(x=12, y=34)
        
    elif mode == "SH":
        
        Label(modeInitWin, text=f'Mode: Shutdown').place(x=12, y=34)


    Label(modeInitWin, text=f'youtube.com/@CalvinCoolest').place(x=12, y=67)



    # This is the section of code which creates the a label
    #if mode == "CU":
    #    Label(modeInitWin, text=f'CMD Command: "{CMDCOMMAND}"').place(x=12, y=64)


    modeInitWin.mainloop()

#mode_init code ends#####################################################################################################

def crash_mode():

    global crashWindow

    root.destroy()
    # this is a function to check the status of the checkbox (1 means checked, and 0 means unchecked)
    def getCheckboxValueCrash():
            checkedOrNot = crashModeCB_oneVar.get()
            return checkedOrNot


    # this is the function called when the button is clicked
    def startBtnCrash():
        global crashWindow
        if getCheckboxValueCrash() == 1:
            crashWindow.destroy()
            mode_init("CR")
        else:
            messagebox.showwarning("SD v2", "You need to check all the checkboxes to continue.")


    crashWindow = Tk()
    #this is the declaration of the variable associated with the checkbox
    crashModeCB_oneVar = tk.IntVar()



    # This is the section of code which creates the main window
    crashWindow.geometry('469x295+200+200')
    crashWindow.title('SD v2 - Crash Mode')


    # This is the section of code which creates a checkbox
    crashModeCB_one=Checkbutton(crashWindow, text='I have closed all other instances of MC.', variable=crashModeCB_oneVar)
    crashModeCB_one.place(x=27, y=22)


    # This is the section of code which creates a button
    Button(crashWindow, text='Start -->', command=startBtnCrash).place(x=378, y=248)


    # This is the section of code which creates the a label
    Label(crashWindow, text='Once you press start, you will have\n10 seconds to maximize MC.').place(x=28, y=198)


    crashWindow.mainloop()


#ShutdownMode code begins################################################################################################

def shutdown_mode():

    root.destroy()


    # this is a function to check the status of the checkbox (1 means checked, and 0 means unchecked)
    def getCheckboxValue1():
            checkedOrNot = shutdownCheckVar.get()
            return checkedOrNot


    # this is the function called when the button is clicked
    def startBtnShutdown():
        if getCheckboxValue1() == 1 and getCheckboxValue2() == 1 and getCheckboxValue3() == 1:
                SDwindow.destroy()
                mode_init("SH")
        else:
            messagebox.showwarning("SD v2", "You need to check all the checkboxes to continue.")



    # this is a function to check the status of the checkbox (1 means checked, and 0 means unchecked)
    def getCheckboxValue2():
            checkedOrNot = shutdownCheckPackVar.get()
            return checkedOrNot


    # this is a function to check the status of the checkbox (1 means checked, and 0 means unchecked)
    def getCheckboxValue3():
            checkedOrNot = shutdownCheckMcVar.get()
            return checkedOrNot



    SDwindow = Tk()
    #this is the declaration of the variable associated with the checkbox
    shutdownCheckVar = tk.IntVar()


    #this is the declaration of the variable associated with the checkbox
    shutdownCheckPackVar = tk.IntVar()


    #this is the declaration of the variable associated with the checkbox
    shutdownCheckMcVar = tk.IntVar()



    # This is the section of code which creates the main window
    SDwindow.geometry('430x250+200+200')
    SDwindow.title('SD v2 - Shutdown Mode')


    # This is the section of code which creates a checkbox
    shutdownCheck=Checkbutton(SDwindow, text='I saved all files open on my PC', variable=shutdownCheckVar)
    shutdownCheck.place(x=30, y=23)


    # This is the section of code which creates a button
    Button(SDwindow, text='Start -->', command=startBtnShutdown).place(x=360, y=203)


    # This is the section of code which creates a checkbox
    shutdownCheckPack=Checkbutton(SDwindow, text='I applied the resource pack', variable=shutdownCheckPackVar)
    shutdownCheckPack.place(x=30, y=63)


    # This is the section of code which creates a checkbox
    shutdownCheckMC=Checkbutton(SDwindow, text='MC is open in a world/server', variable=shutdownCheckMcVar)
    shutdownCheckMC.place(x=30, y=103)


    # This is the section of code which creates the a label
    Label(SDwindow, text='Once you press start, you will have\n10 seconds to maximize MC.').place(x=30, y=153)


    SDwindow.mainloop()

#ShutdownMode code ends#################################################################################################

def custom_mode():

    global CMDCOMMAND
    root.destroy()

    # this is a function to get the user input from the text input box
    def getInputBoxValue():
            userInput = cmdCommand.get()
            return userInput


    # this is a function to check the status of the checkbox (1 means checked, and 0 means unchecked)
    def getCrashCheckboxValue():
            checkedOrNot = checkboxCrashVar.get()
            return checkedOrNot


    # this is the function called when the button is clicked
    def startBtnCustom():
            global CMDCOMMAND
            if getCrashCheckboxValue() == 1:
                CMDCOMMAND = getInputBoxValue()
                if CMDCOMMAND == "":
                    messagebox.showwarning("SD v2", "'Input CMD Command' field is blank.")
                else:
                    customWindow.destroy()
                    mode_init("CU")
                
            else:
                messagebox.showwarning("SD v2", "You need to check all the checkboxes to continue.")




    customWindow = Tk()
    #this is the declaration of the variable associated with the checkbox
    checkboxCrashVar = tk.IntVar()



    # This is the section of code which creates the main window
    customWindow.geometry('434x248+200+200')
    customWindow.configure()
    customWindow.title('SD v2 - Custom Mode')


    # This is the section of code which creates the a label
    Label(customWindow, text='Input  CMD command:').place(x=27, y=10)


    # This is the section of code which creates a text input box
    cmdCommand=Entry(customWindow)
    cmdCommand.place(x=197, y=10)


    # This is the section of code which creates the a label
    Label(customWindow, text='Warning! Make sure you\nknow what you are doing, since you\ncould potentially damage your PC.\nBe careful!').place(x=27, y=50)


    # This is the section of code which creates a checkbox
    checkboxCrash=Checkbutton(customWindow, text="I know what I'm doing.", variable=checkboxCrashVar)
    checkboxCrash.place(x=27, y=140)

    Label(customWindow, text='Once you press start, you will have\n10 seconds to maximize MC.').place(x=30, y=193)


    # This is the section of code which creates a button
    Button(customWindow, text='Start -->', command=startBtnCustom).place(x=337, y=200)


    customWindow.mainloop()


def tryout_mode():

    root.destroy()
    # this is a function to check the status of the checkbox (1 means checked, and 0 means unchecked)
    def getTOCV():
            checkedOrNot = tryOutCheckVar.get()
            return checkedOrNot


    # this is the function called when the button is clicked
    def tryOutStartBtn():
        tryOutWindow.destroy()
        mode_init("TR")



    tryOutWindow = Tk()
    #this is the declaration of the variable associated with the checkbox
    tryOutCheckVar = tk.IntVar()



    # This is the section of code which creates the main window
    tryOutWindow.geometry('500x270+200+200')
    tryOutWindow.configure()
    tryOutWindow.title('SD v2 - Try Out')


    # This is the section of code which creates a checkbox
    #tryOutCheck=Checkbutton(tryOutWindow, text='I\'m ready to try!', variable=tryOutCheckVar)
    #tryOutCheck.place(x=26, y=17)


    # This is the section of code which creates a button
    Button(tryOutWindow, text='Start -->', command=tryOutStartBtn).place(x=396, y=217)


    # This is the section of code which creates the a label
    Label(tryOutWindow, text='Once you press start, you will have\n10 seconds to maximize MC.').place(x=26, y=17)

    tryOutWindow.mainloop()




def getSelectedComboItem():
	return program_modeSelector.get()

def nextbtn():
        
    program_mode = getSelectedComboItem()

    if program_mode.lower() == "crash" or program_mode.lower() == "shutdown" or program_mode.lower() == "custom" or program_mode.lower() == "try out":
            
        if program_mode.lower() == "crash":
                crash_mode()
                
        elif program_mode.lower() == "shutdown":
                shutdown_mode()
                
        elif program_mode.lower() == "custom":
                custom_mode()

        elif program_mode.lower() == "try out":
                tryout_mode()
    
    else:
        messagebox.showerror("Error", "Please select one of the options from the drop-down menu.")




root = Tk()

root.geometry('500x270+200+200')
root.title('SD v2 - By CalvinCoolest')


program_modeSelector= ttk.Combobox(root, values=['Shutdown', 'Try Out', 'Crash', 'Custom'], font=('arial', 9, 'normal'), width=10)
program_modeSelector.place(x=33, y=33)
program_modeSelector.current(1)


Button(root, text='Next -->', command=nextbtn).place(x=396, y=217)


Label(root, text='Make sure you read INSTRUCTIONS.TXT\nbefore continuing.').place(x=33, y=200)


Label(root, text='Shutdown - Shutdown your PC when you take damage').place(x=183, y=36)


Label(root, text='Try Out - Messagebox when you take damage').place(x=183, y=66)


Label(root, text='Crash - Closes MC when you take damage').place(x=183, y=96)


Label(root, text='Custom - Run a CMD command when you take damage').place(x=183, y=126)


root.mainloop()
